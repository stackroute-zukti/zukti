let express = require('express');
let router = express.Router();
let getNeo4jDriver = require('../../neo4j/connection');
var countcorrect=[];
var countwrong=[];
var array1=[];
var array2=[];
router.post('/getAssesmentQuestion', function(req, res) {
  console.log("inside", req.body.domain);
  let query = 'match (n:testdomain {name:"' + req.body.domain + '"})-[*]->(j:testquestion)\
  return collect (distinct j) as question,id(j)';
  // let query = 'match (n:testdomain {name:"'+req.body.domain+'"})-[*]-(j:testquestion)\
  // return j,id(j)';
  //let query = 'MATCH (n:testquestion) RETURN n';
  let session = getNeo4jDriver().session();
  var question = [];
  session.run(query).then(function(result) {
    console.log("Record length is : " + result.records.length);
    for (let i = 0; i < result.records.length; i++) {
      var obj = {};
      var answer = result.records[i]._fields["0"]["0"].properties.answer;
      var option = result.records[i]._fields["0"]["0"].properties.option;
      var correct = option.indexOf(answer);
      obj["question"] = result.records[i]._fields["0"]["0"].properties.question;
      obj["answers"] = option;
      obj["correct"] = correct;
      obj["id"] = result.records[i]._fields["0"]["0"].identity.low;
      question.push(obj);
    }
    console.log("question length is : ", question.length);
    res.send(question);
    session.close();
  });
});

router.post('/getQuestionOnOption', function(req, res) {
  let query = 'match (n:testquestion) where n.type="' + req.body.domain + '" return n';
  let session = getNeo4jDriver().session();
  session.run(query).then(function(result) {
    res.send(result);
    session.close();
  });
});

router.post('/setDifficulty', function(req, res) {
countcorrect=[];
countwrong=[];
  var correct = JSON.parse(req.body.correctquestion);
array1=correct;
  var wrong = JSON.parse(req.body.wrongquestion);
  array2=wrong;
  let query = 'unwind [ ' + correct + ' ]as count\
         match(n:testquestion)-[b:attempted_by{type:"correct"}]-(c)where ID(n)=count\
         with collect(count) as on\
         return collect( on);';

  let session = getNeo4jDriver().session();
  session.run(query).then(function(result) {
    for (let i = 0; i < result.records["0"]._fields["0"]["0"].length; i++) {
      countcorrect.push(result.records["0"]._fields["0"]["0"][i].low);

    }
console.log("countccccc",countcorrect);
    session.close();
  });
  let query1 = 'unwind [ ' + wrong + ' ]as count\
           match(n:testquestion)-[b:attempted_by{type:"wrong"}]-(c)where ID(n)=count\
           with collect(count) as on\
           return collect( on);';


  session.run(query1).then(function(result) {
    for (let i = 0; i < result.records["0"]._fields["0"]["0"].length; i++) {
      countwrong.push(result.records["0"]._fields["0"]["0"][i].low);
    }
console.log("countwwwwwww",countwrong);
    session.close();
  });
res.send("success");
});
router.get('/setDifficulty', function(req, res) {
  console.log("inside set");
  console.log("countcorrect",countcorrect);
  console.log("countwrong",countwrong);
  var d=1;
  for(let i=0;i<array1.length;i++)
  {
    console.log(array1[i]);
          var count1 = countcorrect.reduce(function(n, val) {
            return n + (val === array1[i]);
            }, 0);
        var count2 = countwrong.reduce(function(n, val) {
          return n + (val === array1[i]);
          }, 0);
        console.log("correct count1",count1);
        console.log("correct count2",count2);
        var total=count1+count2;
        var diff=(count1/total)*100;

        console.log("diss",diff);
        if(diff>=90)
        {
          d=1;
        }
        if(diff<90 && diff>=80)
        {
          d=2;
        }
        if(diff<80 && diff>=70)
        {
          d=3;
        }
        if(diff<70 && diff>=50)
        {
          d=4;
        }
        if(diff<50)
        {
          d=5;
        }

          let session = getNeo4jDriver().session();
        let query1 = 'MATCH (n:testquestion) where ID(n)='+array1[i]+' set n.difficulty ='+d+' return n';
        session.run(query1).then(function(result) {
        console.log(result);

          session.close();
        });
  }
  for(let i=0;i<array2.length;i++)
  {
    console.log(array2[i]);
          var count1 = countcorrect.reduce(function(n, val) {
            return n + (val === array2[i]);
            }, 0);
        var count2 = countwrong.reduce(function(n, val) {
          return n + (val === array2[i]);
          }, 0);
        console.log("wrong count1",count1);
        console.log("wrong count2",count2);
        var total=count1+count2;
        var diff=(count1/total)*100;

        console.log("wrong percentage",diff);
        if(diff>=90)
        {
          d=1;
        }
        if(diff<90 && diff>=80)
        {
          d=2;
        }
        if(diff<80 && diff>=70)
        {
          d=3;
        }
        if(diff<70 && diff>=50)
        {
          d=4;
        }
        if(diff<50)
        {
          d=5;
        }

        let session = getNeo4jDriver().session();
        let query1 = 'MATCH (n:testquestion) where ID(n)='+array2[i]+' set n.difficulty ='+d+' return n';
        session.run(query1).then(function(result) {
        console.log(result);

          session.close();
        });
  }
});


module.exports = router;
