/* @navinprasad: create redis client */
let redis = require('redis').createClient();
module.exports = redis;
