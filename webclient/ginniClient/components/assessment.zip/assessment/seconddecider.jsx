import React, { Component } from 'react'
import { Button, Modal } from 'semantic-ui-react'
import {hashHistory} from 'react-router';


class SecondDecider extends Component {
  state = { open: true }

  show = (size) => () => this.setState({ size, open: true })
  //close = () => this.setState({ open: false })
  close = () => hashHistory.push('/chat/react');


  render() {
    const { open, size } = this.state

    return (
      <div>

      <Modal size={size} open={open} onClose={this.close}  onMount={this.fetchValuesFromDatabase}
      closeOnRootNodeClick={false} size="tiny" closeIcon='close' id='modallogincss'>

      <Modal.Header>
      Timed test decider!
      </Modal.Header>
      <Modal.Content>
      <p>Select the type of test you want to take</p>
      </Modal.Content>
      <Modal.Actions>
      <a href="#timer">     <Button icon ='time' color='red'   onClick={this.close}>TIMEed('x' mins)</Button> </a>

      <a href="#timer1" ><Button color='blue' icon='time' labelPosition='left' onClick={this.close}>TIMEless</Button></a>

      </Modal.Actions>
      </Modal>
      </div>
      )
  }
}

export default SecondDecider
